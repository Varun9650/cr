import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../bracket_view_model.dart';

class BracketOverviewScreen extends StatefulWidget {
  const BracketOverviewScreen({Key? key}) : super(key: key);

  @override
  State<BracketOverviewScreen> createState() => _BracketOverviewScreenState();
}

class _BracketOverviewScreenState extends State<BracketOverviewScreen> {
  final GlobalKey _captureKey = GlobalKey();

  static const double _cardWidth = 220;
  static const double _cardHeight = 90;
  static const double _hGap = 60;
  static const double _vGap = 24;

  Future<void> _exportAsImage() async {
    try {
      final boundary = _captureKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) return;

      final ui.Image image = await boundary.toImage(pixelRatio: 3);
      final ByteData? byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) return;
      final Uint8List pngBytes = byteData.buffer.asUint8List();

      final Directory dir = await getApplicationDocumentsDirectory();
      final String filePath =
          '${dir.path}/bracket_overview_${DateTime.now().millisecondsSinceEpoch}.png';
      final File imgFile = File(filePath);
      await imgFile.writeAsBytes(pngBytes);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Bracket image saved to: $filePath'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 3),
        ),
      );
    } on MissingPluginException catch (_) {
      await _exportAsPdf();
    } catch (e) {
      // Any other image export error â fallback to PDF
      await _exportAsPdf();
    }
  }

  Future<void> _exportAsPdf() async {
    try {
      final boundary = _captureKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) return;
      final ui.Image image = await boundary.toImage(pixelRatio: 3);
      final ByteData? byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) return;
      final Uint8List pngBytes = byteData.buffer.asUint8List();

      final doc = pw.Document();
      final imageProvider = pw.MemoryImage(pngBytes);

      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4.landscape,
          build: (pw.Context context) {
            return pw.Stack(children: [
              pw.Container(
                alignment: pw.Alignment.center,
                padding: const pw.EdgeInsets.all(12),
                child: pw.FittedBox(
                  child: pw.Image(imageProvider),
                  fit: pw.BoxFit.contain,
                ),
              ),
            ]);
          },
        ),
      );

      final filename =
          'bracket_overview_${DateTime.now().millisecondsSinceEpoch}.pdf';

      // Prefer native share/print flow which also enables download on web
      await Printing.sharePdf(bytes: await doc.save(), filename: filename);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('PDF ready for download/share.'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to export PDF: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BracketViewModel>(
      builder: (context, vm, _) {
        final totalRounds = vm.getTotalRounds();
        final firstRoundMatches = vm.getMatchesForRound(1);
        final int baseCount =
            firstRoundMatches.isEmpty ? 0 : firstRoundMatches.length;
        final category =
            vm.selectedGroup.isNotEmpty ? vm.selectedGroup : 'Category';

        // Compute canvas size
        final double canvasWidth =
            totalRounds * _cardWidth + (totalRounds - 1) * _hGap + 80;
        final double canvasHeight = baseCount == 0
            ? 400
            : (baseCount * _cardHeight) + ((baseCount - 1) * _vGap) * 2;

        final Map<String, Offset> leftCenters = {};
        final Map<String, Offset> rightCenters = {};

        // Precompute positions for all matches
        final List<_OverviewNode> nodes = [];
        for (int round = 1; round <= totalRounds; round++) {
          final matches = vm.getMatchesForRound(round);
          final int matchesInRound = matches.length;
          final double x = 40 + (round - 1) * (_cardWidth + _hGap);
          // Separation between items in this round to center over their parents
          final double separation = (round == 1)
              ? (_cardHeight + _vGap)
              : (_cardHeight + _vGap) * (1 << (round - 1));
          for (int j = 0; j < matchesInRound; j++) {
            final match = matches[j];
            final int index1Based = j + 1;
            final double y = (index1Based - 1) * separation +
                (separation - _cardHeight) / 2 +
                40;
            final Rect rect = Rect.fromLTWH(x, y, _cardWidth, _cardHeight);
            final String id = match['match_id'].toString();
            nodes.add(_OverviewNode(id: id, rect: rect, match: match));
            leftCenters[id] = Offset(rect.left, rect.center.dy);
            rightCenters[id] = Offset(rect.right, rect.center.dy);
          }
        }

        // Build connections between rounds based on match id numbering
        final List<_OverviewEdge> edges = [];
        for (int round = 1; round < totalRounds; round++) {
          final matches = vm.getMatchesForRound(round);
          for (int j = 0; j < matches.length; j++) {
            final String currentId = matches[j]['match_id'].toString();
            final int currentNumber = _extractMatchNumber(currentId);
            final int nextRound = round + 1;
            final int nextMatchNumber = (currentNumber + 1) ~/ 2;
            final String nextId = 'match_${nextRound}_${nextMatchNumber}';
            final Offset? src = rightCenters[currentId];
            final Offset? dst = leftCenters[nextId];
            if (src != null && dst != null) {
              edges.add(_OverviewEdge(from: src, to: dst));
            }
          }
        }

        return Scaffold(
          backgroundColor: Colors.grey[100],
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 0.5,
            title: Row(
              children: [
                Text(
                  'Bracket Overview',
                  style: GoogleFonts.getFont('Poppins', color: Colors.black),
                ),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE3F2FD),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF90CAF9)),
                  ),
                  child: Text(
                    category,
                    style: GoogleFonts.getFont('Poppins',
                        color: const Color(0xFF1565C0),
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'Download',
                icon: const Icon(Icons.download, color: Colors.black),
                onPressed: _exportAsImage,
              ),
            ],
            leading: IconButton(
              icon: const Icon(Icons.close, color: Colors.black),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: RepaintBoundary(
            key: _captureKey,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Container(
                  color: Colors.grey[100],
                  width: canvasWidth,
                  height: canvasHeight,
                  child: Stack(
                    children: [
                      // Connectors
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _BracketConnectorPainter(edges: edges),
                        ),
                      ),
                      // Category chip inside canvas (appears in download)
                      Positioned(
                        right: 8,
                        bottom: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: const Color(0xFF90CAF9)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.06),
                                blurRadius: 3,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            category,
                            style: GoogleFonts.getFont('Poppins',
                                color: const Color(0xFF1565C0),
                                fontSize: 12,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                      // Round headers
                      for (int round = 1; round <= totalRounds; round++)
                        Positioned(
                          left: 40 + (round - 1) * (_cardWidth + _hGap),
                          top: 0,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFF264653),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.08),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Text(
                              'Round $round',
                              style: GoogleFonts.getFont('Poppins',
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      // Cards
                      for (final node in nodes)
                        Positioned(
                          left: node.rect.left,
                          top: node.rect.top,
                          width: node.rect.width,
                          height: node.rect.height,
                          child: _OverviewMatchCard(match: node.match),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  int _extractMatchNumber(String matchId) {
    // match_3_2 -> 2
    try {
      final parts = matchId.split('_');
      return int.tryParse(parts.last) ?? 1;
    } catch (_) {
      return 1;
    }
  }
}

class _OverviewNode {
  final String id;
  final Rect rect;
  final Map<String, dynamic> match;

  _OverviewNode({required this.id, required this.rect, required this.match});
}

class _OverviewEdge {
  final Offset from;
  final Offset to;
  _OverviewEdge({required this.from, required this.to});
}

class _BracketConnectorPainter extends CustomPainter {
  final List<_OverviewEdge> edges;
  _BracketConnectorPainter({required this.edges});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF90CAF9)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    for (final e in edges) {
      final double midX = (e.from.dx + e.to.dx) / 2;
      final path = Path()
        ..moveTo(e.from.dx, e.from.dy)
        ..lineTo(midX, e.from.dy)
        ..lineTo(midX, e.to.dy)
        ..lineTo(e.to.dx, e.to.dy);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _BracketConnectorPainter oldDelegate) {
    return oldDelegate.edges != edges;
  }
}

class _OverviewMatchCard extends StatelessWidget {
  final Map<String, dynamic> match;
  const _OverviewMatchCard({Key? key, required this.match}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final team1 = match['team1'];
    final team2 = match['team2'];
    final winner = match['winner'];
    final status = match['status'];

    Color cardColor = Colors.white;
    Color borderColor = Colors.grey[300]!;
    double borderWidth = 1;

    if (status == 'completed') {
      cardColor = Colors.green[50]!;
      borderColor = Colors.green[700]!;
      borderWidth = 1.5;
    } else if (status == 'ready') {
      cardColor = Colors.blue[50]!;
      borderColor = Colors.blue[700]!;
      borderWidth = 1.5;
    }

    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderColor, width: borderWidth),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 3,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _teamLine(team1, isWinner: winner != null && winner == team1),
          const Divider(height: 10),
          _teamLine(team2, isWinner: winner != null && winner == team2),
        ],
      ),
    );
  }

  Widget _teamLine(dynamic team, {required bool isWinner}) {
    final isDummy = team == 'BYE';
    final isEmpty = team == null || team.toString().trim().isEmpty;
    return Row(
      children: [
        if (isWinner && !isEmpty && !isDummy)
          const Icon(Icons.check_circle, color: Colors.green, size: 14),
        if (isWinner && !isEmpty && !isDummy) const SizedBox(width: 4),
        Expanded(
          child: Text(
            isEmpty ? 'TBD' : (isDummy ? 'BYE' : team.toString()),
            style: GoogleFonts.getFont(
              'Poppins',
              fontSize: 12,
              fontWeight: isWinner ? FontWeight.w600 : FontWeight.w400,
              color: isDummy
                  ? Colors.grey[700]
                  : (isEmpty ? Colors.grey[600] : Colors.black),
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
